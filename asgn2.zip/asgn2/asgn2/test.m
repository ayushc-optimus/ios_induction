//
//  test.m
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import "test.h"

@implementation test
- (void)displayName{
    
}
+ (void)displaySupername{
    
}
@end
