//
//  CollectionViewCell.h
//  asgn2
//
//  Created by ayush on 2/4/15.
//
//
#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell
@property (nonatomic, weak) IBOutlet UIImageView *imgView;

@end
