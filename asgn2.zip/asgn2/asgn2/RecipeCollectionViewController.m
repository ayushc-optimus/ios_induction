//
//  RecipeCollectionViewController.m
//  asgn2
//
//  Created by ayush on 2/4/15.
//
//

#import "RecipeCollectionViewController.h"
#import "CVC.h"
#import "CollectionViewCell.h"




@interface RecipeCollectionViewController () {
    
}
@end

@implementation RecipeCollectionViewController
{NSArray *recipePhotos;}
static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    recipePhotos = [NSArray arrayWithObjects:@"angry_birds_cake.jpg", @"creme_brelee.jpg", @"egg_benedict.jpg", @"full_breakfast.jpg", @"green_tea.jpg", @"ham_and_cheese_panini.jpg", @"ham_and_egg_sandwich.jpg", @"hamburger.jpg", @"instant_noodle_with_egg.jpg", @"japanese_noodle_with_pork.jpg", @"mushroom_risotto.jpg", @"noodle_with_bbq_pork.jpg", @"starbucks_coffee.jpg", @"thai_shrimp_cake.jpg", @"vegetable_curry.jpg", @"white_chocolate_donut.jpg", nil];

    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Register cell classes
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return recipePhotos.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *identifier = @"Celll";
    
    CollectionViewCell *celll = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    // Configure the cell
    celll.imgView.image = [UIImage imageNamed:[recipePhotos objectAtIndex:indexPath.row]];
    
    return celll;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"seg"]) {
       NSArray *indexPaths = [self.collectionView indexPathsForSelectedItems];
       CVC *destViewController = segue.destinationViewController;
       NSIndexPath *indexPath = [indexPaths objectAtIndex:0];
        destViewController.ImageName = [recipePhotos objectAtIndex:indexPath.row];
        
    }
}
@end
