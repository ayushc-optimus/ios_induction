//
//  VC.m
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import "VC.h"

@interface VC ()

@end

@implementation VC
{
 
}
@synthesize recipeLabel;
@synthesize item;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.img.image =[UIImage imageNamed:self.imageName];
    recipeLabel.text = item;
   }
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
