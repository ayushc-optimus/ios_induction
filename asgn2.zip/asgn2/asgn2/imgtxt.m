//
//  imgtxt.m
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import "imgtxt.h"

@implementation imgtxt

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // Here we set the navigationItem.title to the stringTitle. stringTitle is declared in the .h. Think of it as a global scope variable. It is also propertised in the .h and then synthesized in the .m of ProteinView.
    self.navigationItem.title = stringTitle;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    ProteinView *detailViewController = [[ProteinView alloc] initWithNibName:@"ProteinView" bundle:nil];
    
    // It is here we'd pass information from the currently selected UITableViewCell to the ProteinView.
    // An example of this is the following.
    
    // I would do it like this, but others would differ slightly.
    NSString *titleString = [[[NSString alloc] initWithFormat:@"iPad %d",indexPath.row] autorelease];
    
    // title is an object of detailViewController (ProteinView). In my own instances, I have always made a NSString which in viewDiDLoad is made the self.navigationBar.title string. Look below for what my ProteinView.m and .h would look like.
    detailViewController.stringTitle = titleString;
    // ...
    // Pass the selected object to the new view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
}

@end