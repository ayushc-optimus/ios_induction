//
//  CVC.m
//  asgn2
//
//  Created by ayush on 2/5/15.
//
//

#import "CVC.h"

@interface CVC ()

@end

@implementation CVC


{  NSArray *gridpic;}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.recipeImageView.image = [UIImage imageNamed:self.ImageName];
    // Do any additional setup after loading the view.
    gridpic = [NSArray arrayWithObjects:@"angry_birds_cake.jpg", @"creme_brelee.jpg", @"egg_benedict.jpg", @"full_breakfast.jpg", @"green_tea.jpg", @"ham_and_cheese_panini.jpg", @"ham_and_egg_sandwich.jpg", @"hamburger.jpg", @"instant_noodle_with_egg.jpg", @"japanese_noodle_with_pork.jpg", @"mushroom_risotto.jpg", @"noodle_with_bbq_pork.jpg", @"starbucks_coffee.jpg", @"thai_shrimp_cake.jpg", @"vegetable_curry.jpg", @"white_chocolate_donut.jpg", nil];}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)close:(id)sender {
    
    exit(1);
}
@end
