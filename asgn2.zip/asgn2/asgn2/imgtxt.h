//
//  imgtxt.h
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import <UIKit/UIKit.h>

@interface imgtxt : UIView

@end
