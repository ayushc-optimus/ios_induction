//
//  test.h
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import <Foundation/Foundation.h>

@interface test : NSObject

@property (nonatomic,strong) NSString *strName;

- (void)displayName;
+ (void)displaySupername;
@end
