//
//  new.h
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import <UIKit/UIKit.h>

@interface new : UIViewController

@end
