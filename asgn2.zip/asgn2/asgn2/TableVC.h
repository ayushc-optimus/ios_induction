//
//  TableVC.h
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import <UIKit/UIKit.h>

@interface TableVC : UITableViewController <UITableViewDelegate, UITableViewDataSource>
{
    
}
@property (nonatomic, strong) IBOutlet UITableView *tableView;

@end