//
//  TableVC.m
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import "TableVC.h"
#import "VC.h"

/*@interface SimpleTableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@end*/

@interface TableVC ()

@end

@implementation TableVC
{
    NSArray *tableData;
    NSArray *thumbnails;
}
@synthesize tableView;
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Initialize table data
    tableData = [NSArray arrayWithObjects:@"Egg Benedict", @"Mushroom Risotto", @"Full Breakfast", @"Hamburger", @"Ham and Egg Sandwich", @"Creme Brelee", @"White Chocolate Donut", @"Starbucks Coffee", @"Vegetable Curry", @"Instant Noodle with Egg", @"Noodle with BBQ Pork", @"Japanese Noodle with Pork", @"Green Tea", @"Thai Shrimp Cake", @"Angry Birds Cake", @"Ham and Cheese Panini", nil];
    thumbnails = [NSArray arrayWithObjects:@"egg_benedict.jpg", @"mushroom_risotto.jpg", @"full_breakfast.jpg", @"hamburger.jpg", @"ham_and_egg_sandwich.jpg", @"creme_brelee.jpg", @"white_chocolate_donut.jpg", @"starbucks_coffee.jpg", @"vegetable_curry.jpg", @"instant_noodle_with_egg.jpg", @"noodle_with_bbq_pork.jpg", @"japanese_noodle_with_pork.jpg", @"green_tea.jpg", @"thai_shrimp_cake.jpg", @"angry_birds_cake.jpg", @"ham_and_cheese_panini.jpg", nil];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [tableData count];
}

- (UITableViewCell *)tableView:(UITableView *)_tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
     NSString *simpleTableIdentifier = @"BookletCell";
    
    UITableViewCell *cell = [_tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = [tableData objectAtIndex:indexPath.row];
    
    cell.imageView.image = [UIImage imageNamed:[thumbnails objectAtIndex:indexPath.row]];
    return cell;
    
}

-(void) tableView:(UITableView *)_tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
   [_tableView deselectRowAtIndexPath:indexPath animated:YES];
  
}

-(void) performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    [self performSegueWithIdentifier:@"asd" sender:self];

}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender

{    if ([[segue identifier] isEqualToString:@"asd"])
    {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
             
        VC *vc = segue.destinationViewController;
        vc.item =[tableData objectAtIndex:indexPath.row];
        vc.imageName =[thumbnails objectAtIndex:indexPath.row];

}
}

@end