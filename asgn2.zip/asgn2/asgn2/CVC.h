//
//  CVC.h
//  asgn2
//
//  Created by ayush on 2/5/15.
//
//

#import <UIKit/UIKit.h>

@interface CVC : UIViewController

@property (weak, nonatomic) NSString *ImageName;
@property(weak, nonatomic) IBOutlet UIImageView *recipeImageView;
- (IBAction)close:(id)sender;

@end
