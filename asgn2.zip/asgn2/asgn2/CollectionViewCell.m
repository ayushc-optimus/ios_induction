//
//  CollectionViewCell.m
//  asgn2
//
//  Created by ayush on 2/4/15.
//
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

@end
