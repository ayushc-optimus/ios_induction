//
//  RecipeViewController.h
//  asgn2
//
//  Created by ayush on 2/4/15.
//
//

#import <UIKit/UIKit.h>

@interface RecipeViewController : UIViewController

@property (weak, nonatomic) NSString *recipeImageName;
- (IBAction)close:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *RecipeImageView;


