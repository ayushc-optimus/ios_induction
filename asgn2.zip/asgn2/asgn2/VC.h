//
//  VC.h
//  asgn2
//
//  Created by ayush on 2/3/15.
//
//

#import <UIKit/UIKit.h>

@interface VC : UIViewController{
}
@property (nonatomic, weak) IBOutlet UIImageView *img;
@property(nonatomic,weak) NSString * item;
@property(nonatomic,weak) NSString * imageName;
@property (nonatomic, strong) IBOutlet UILabel *recipeLabel;

@end
