//
//  TableViewController.h
//  asgn2
//
//  Created by ayush on 2/4/15.
//
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController

@end
