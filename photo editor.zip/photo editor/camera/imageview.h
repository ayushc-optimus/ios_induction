//
//  imageview.h
//  camera
//
//  Created by ayush on 2/27/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageview : UIImageView <
UINavigationControllerDelegate,UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imagev;

-(IBAction)handleRotate:(UIRotationGestureRecognizer *)recognizer;
- (IBAction)handlePan:(UIPanGestureRecognizer *)recognizer;
- (IBAction)handlePinch:(UIPinchGestureRecognizer *)recognizer;

@end
