//
//  ViewController.h
//  camera
//
//  Created by ayush on 2/5/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface ViewController : UIViewController <UIImagePickerControllerDelegate,
    UINavigationControllerDelegate,UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIButton *save;
@property (weak, nonatomic) IBOutlet UIButton *source;
@property (weak, nonatomic) IBOutlet UIButton *text;
@property (weak, nonatomic) IBOutlet UIImageView *imageview;

@property(weak,nonatomic) UIImage *chosenImage;
@property(weak,nonatomic) UIImage *newimg ;

- (IBAction)source:(id)sender;
- (IBAction)text:(id)sender;

@end

