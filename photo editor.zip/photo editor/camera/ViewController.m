//
//  ViewController.m
//  camera
//
//  Created by ayush on 2/5/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import "ViewController.h"
#import "imageview.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

}

-(void) source:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Source"
                          message:@"Choose relevant source"
                          delegate:self
                          cancelButtonTitle:@"Cancel"
                          otherButtonTitles:@"camera",@"gallery", nil];
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        if ([UIImagePickerController isSourceTypeAvailable:
             UIImagePickerControllerSourceTypeCamera])
        {   picker.delegate = self;
            picker.allowsEditing = YES;
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentViewController:picker animated:YES completion:NULL];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"prompt"                                                   message:@"Camera not available"                                                  delegate:self                                         cancelButtonTitle:@"OK"                                         otherButtonTitles:nil];
            [alert show];
        }
    }
    else if (buttonIndex == 2)
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:picker animated:YES completion:NULL];
      
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    _chosenImage = info[UIImagePickerControllerEditedImage];
    self.imageview.image=_chosenImage;

    [picker dismissViewControllerAnimated:YES completion:NULL];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)save:(id)sender
{
    [self createImage:_imageview];
}

-(UIImage *)createImage:(UIImageView *)imgView
{
    UIGraphicsBeginImageContextWithOptions(_imageview.bounds.size, YES, 1.5);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    [_imageview.layer renderInContext:context];
    UIImage *imgs = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImageWriteToSavedPhotosAlbum(imgs, nil, nil, nil);
    return imgs;
  }

-(IBAction)text:(id)sender
{
    
    if (_imageview.image==Nil) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"prompt"                                                   message:@"select image first!"                                                  delegate:self                                         cancelButtonTitle:@"OK"                                         otherButtonTitles:nil];
        [alert show];

    }
    else{
    UITextField *myfield = [[UITextField alloc] initWithFrame:CGRectMake(400, 400, 400, 40)];
        myfield.text = @"edit text here ";
        [_imageview addSubview:myfield];
        [myfield setUserInteractionEnabled:YES];
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    myfield.clearsOnBeginEditing=YES;    
    [myfield addGestureRecognizer:panGesture];
        panGesture = nil;}
}

- (IBAction)handlePanGesture:(UIPanGestureRecognizer *)recognizer
{
    CGPoint translation = [recognizer translationInView:self.imageview];
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,                                        recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self.imageview];    
}

@end
