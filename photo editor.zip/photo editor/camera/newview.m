//
//  newview.m
//  camera
//
//  Created by ayush on 2/26/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import "newview.h"

@interface newview ()

@end

@implementation newview

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) selectt:(id)sender
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.imgview.image = chosenImage;
    
        UITextView *mytextview = [[UITextView alloc] initWithFrame:CGRectMake(50, 50, 250, 40)];
    
    mytextview.text = NSLocalizedString(@"", @"");
        [self.imgview addSubview:mytextview];
    [self.imgview setUserInteractionEnabled:YES];
    [mytextview setUserInteractionEnabled:YES];
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    [panGesture setMinimumNumberOfTouches:1];
    [panGesture setMaximumNumberOfTouches:1];
    
    [mytextview addGestureRecognizer:panGesture];
    panGesture = nil;
   

    
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

//   -(void)handlePanGesture:(id)sender
//{
//    CGPoint translatedPoint = [(UIPanGestureRecognizer*)sender translationInView:self.view];
//    if([(UIPanGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
//        firstX = [[sender view] center].x;
//        firstY = [[sender view] center].y;
//    }
//    translatedPoint = CGPointMake(firstX+translatedPoint.x, firstY+translatedPoint.y);
//    [[sender view] setCenter:translatedPoint];
//}

-(IBAction)save:(id)sender
{ UIImageWriteToSavedPhotosAlbum(self.imgview.image, NULL, NULL, NULL);
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
    


@end
