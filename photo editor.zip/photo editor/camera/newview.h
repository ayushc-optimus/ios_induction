//
//  newview.h
//  camera
//
//  Created by ayush on 2/26/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface newview : UIViewController<UIImagePickerControllerDelegate,
UINavigationControllerDelegate>


@property BOOL newMedia;
@property (weak, nonatomic) IBOutlet UIButton *selectt;
@property (weak, nonatomic) IBOutlet UIImageView *imgview;
@property (weak, nonatomic) IBOutlet UIButton *save;

- (IBAction)selectt:(id)sender;
@end
