//
//  FirstViewController.h
//  twiker
//
//  Created by ayush on 2/19/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textview;

@end

