//
//  CVC.h
//  twiker
//
//  Created by ayush on 2/23/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CVC : UIViewController

@end
