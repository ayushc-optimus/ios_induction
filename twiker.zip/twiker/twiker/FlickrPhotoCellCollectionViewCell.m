//
//  FlickrPhotoCellCollectionViewCell.m
//  twiker
//
//  Created by ayush on 2/20/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import "FlickrPhotoCellCollectionViewCell.h"
#import "FlickrPhoto.h"

@implementation FlickrPhotoCellCollectionViewCell

-(void) setPhoto:(FlickrPhoto *)photo {
    
    if(_photo != photo) {
        _photo = photo;
    }
    self.imageView.image = _photo.thumbnail;
}

@end
