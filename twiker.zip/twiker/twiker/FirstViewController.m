//
//  FirstViewController.m
//  twiker
//
//  Created by ayush on 2/19/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import "FirstViewController.h"
#import "SearchViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    return YES;
}

-(void)viewDidLoad{
    self.textview.delegate = self;
}

#pragma mark -
#pragma mark === Text field delegate methods ===
#pragma mark -

- (BOOL)textFieldShouldReturn:(UITextField *)textField{

    [textField resignFirstResponder];
    return YES;
}

#pragma mark -
#pragma mark === Segue ===
#pragma mark -

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

    if ([segue.identifier isEqualToString:@"SegueSearchView"])
    {
        UITextField *textField = sender;
        SearchViewController *viewController = segue.destinationViewController;
        viewController.query = [NSString stringWithFormat:@"%@", textField.text];
    }
}

@end


