//
//  FlickrPhotoCellCollectionViewCell.h
//  twiker
//
//  Created by ayush on 2/20/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
@class FlickrPhoto;
@interface FlickrPhotoCellCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) IBOutlet UIImageView *imageView;
@property (nonatomic, strong) FlickrPhoto *photo;
@end