//
//  DetailViewController.m
//  twiker
//
//  Created by ayush on 2/25/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import "DetailViewController.h"
#import "SearchViewController.h"


@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
