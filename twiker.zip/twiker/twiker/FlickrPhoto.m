//
//  FlickrPhoto.m
//  Flickr Search
//


#import "FlickrPhoto.h"

@implementation FlickrPhoto

@end
