//
//  TableViewCell.h
//  twiker
//
//  Created by ayush on 2/25/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextView *textview;

@end
