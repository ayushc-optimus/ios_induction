//
//  SearchViewController.h
//  twiker
//
//  Created by ayush on 2/23/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewController.h"

@interface SearchViewController : UITableViewController
{
    NSArray *tweets;
}
@property (nonatomic, copy) NSString *query;

@end
