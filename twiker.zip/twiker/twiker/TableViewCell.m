//
//  TableViewCell.m
//  twiker
//
//  Created by ayush on 2/25/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
       
}

@end
