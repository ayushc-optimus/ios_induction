//
//  ViewController.h
//  database
//
//  Created by ayush on 2/17/15.
//
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
@interface ViewController : UIViewController

- (IBAction)add:(id)sender;
- (IBAction)search:(id)sender;
- (IBAction)browse:(id)sender;


@end

