//
//  TableVC.m
//  database
//
//  Created by ayush on 2/18/15.
//
//

#import "TableVC.h"

@interface TableVC ()

@end

@implementation TableVC
   {
    NSMutableArray *resultArray;
}
- (void)viewDidLoad
    {
    [super viewDidLoad];
    NSString *docsDir;
    NSArray *dirPaths;
    resultArray = [[NSMutableArray alloc]init];
    static sqlite3_stmt *statement = nil;
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains(                                                 NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    
    // Build the path to the database file
    _databasePath = [[NSString alloc]initWithString: [docsDir stringByAppendingPathComponent:                              @"contacts.db"]];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: _databasePath ] == YES)
    {
        const char *dbpath = [_databasePath UTF8String];
        if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK)
        {
          
            NSString *querySQL = [NSString stringWithFormat:
                                  @"select * from employee order by employeecode"];
            const char *query_stmt = [querySQL UTF8String];
            if (sqlite3_prepare_v2(_contactDB,
                                   query_stmt, -1, &statement, NULL) == SQLITE_OK)
            {
                while(sqlite3_step(statement) == SQLITE_ROW)
                {
                        NSString *name = [[NSString alloc] initWithUTF8String:
                                          (const char *) sqlite3_column_text(statement, 0)];
                        [resultArray addObject:name];
                        NSString *designation = [[NSString alloc] initWithUTF8String:
                                                (const char *) sqlite3_column_text(statement, 1)];
                        [resultArray addObject:designation];
                        NSString *employeecode = [[NSString alloc]initWithUTF8String:
                                          (const char *) sqlite3_column_text(statement, 2)];
                        [resultArray addObject:employeecode];
                        NSString *tagline = [[NSString alloc]initWithUTF8String:
                                                 (const char *) sqlite3_column_text(statement, 3)];
                        [resultArray addObject:tagline];
                        NSString *department = [[NSString alloc]initWithUTF8String:
                                                 (const char *) sqlite3_column_text(statement, 4)];
                        [resultArray addObject:department];
                }
                
            }
            
        } sqlite3_finalize(statement);
          sqlite3_close(_contactDB);
    }
    
}

-(void) tableView:(UITableView *)_tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
    {
[_tableView deselectRowAtIndexPath:indexPath animated:YES];
    }

- (void)didReceiveMemoryWarning
   {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
     }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
   {
    // Return the number of rows in the section.
    return [resultArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
   {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSString *data = [resultArray objectAtIndex:indexPath.row];
    cell.textLabel.text = data;
  
    return cell;
}

@end
