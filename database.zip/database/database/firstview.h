//
//  firstview.h
//  database
//
//  Created by ayush on 2/17/15.
//
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
@interface firstview : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *designation;
@property (strong, nonatomic) IBOutlet UITextField *employeecode;
@property (strong, nonatomic) IBOutlet UITextField *tagline;
@property (strong, nonatomic) IBOutlet UITextField *department;
@property (strong, nonatomic) IBOutlet UILabel *status;
@property (strong, nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *contactDB;

- (IBAction)saveData:(id)sender;
- (IBAction)findContact:(id)sender;



@end

