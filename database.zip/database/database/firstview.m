//
//  firstview.m
//  database
//
//  Created by ayush on 2/17/15.
//
//

#import "firstview.h"

@interface firstview ()

@end

@implementation firstview

- (void)viewDidLoad
    {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString *docsDir;
    NSArray *dirPaths;
    
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains(                                                 NSDocumentDirectory, NSUserDomainMask, YES);
    
    docsDir = dirPaths[0];
    
    // Build the path to the database file
    _databasePath = [[NSString alloc]initWithString: [docsDir stringByAppendingPathComponent:                                  @"contacts.db"]];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if ([filemgr fileExistsAtPath: _databasePath ] == NO)
    {
        const char *dbpath = [_databasePath UTF8String];
        
        if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK)
        {
           char *errMsg;
            const char *sql_stmt =
            "CREATE TABLE IF NOT EXISTS employee (NAME TEXT, designation TEXT, employeecode text, department text,tagline text)";
            
           if (sqlite3_exec(_contactDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
          {
               _status.text = @"Failed to create table";
          }
            sqlite3_close(_contactDB);
       } else {
           _status.text = @"Failed to open/create database";
       }
    }
    }
    
   - (void) saveData:(id)sender
     { sqlite3_stmt    *statement;
        const char *dbpath = [_databasePath UTF8String];
        
        if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK)
        {
           
            NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO employee(name,designation,employeecode,tagline,department) VALUES (\"%@\", \"%@\", \"%@\",\"%@\",\"%@\")",_name.text, _designation.text,_employeecode.text,_department.text,_tagline.text];
            const char *insert_stmt = [insertSQL UTF8String];sqlite3_prepare_v2(_contactDB, insert_stmt,-1, &statement, NULL);
            if (sqlite3_step(statement) == SQLITE_DONE)
            { _status.text = @"information added";
                _name.text = @"";
                _designation.text=@"";
                _employeecode.text=@"";
                _department.text=@"";
                _tagline.text=@"";
                        }
            else {
                _status.text = @"Failed to add information";
            }
            sqlite3_finalize(statement);
            sqlite3_close(_contactDB);
        }
    }
- (void) findContact:(id)sender
    {
    const char *dbpath = [_databasePath UTF8String];
    sqlite3_stmt    *statement;
    
    if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:
                              @"SELECT name, designation,employeecode,tagline,department FROM employee WHERE name=\"%@\"",
                              _name.text];
        
        const char *query_stmt = [querySQL UTF8String];
        
        if (sqlite3_prepare_v2(_contactDB,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
        {
            if (sqlite3_step(statement) == SQLITE_ROW)
            {
                NSString *designation = [[NSString alloc]
                                          initWithUTF8String:
                                          (const char *) sqlite3_column_text(
                                                                             statement, 1)];
                _designation.text = designation;
                NSString *employeecode = [[NSString alloc]
                                        initWithUTF8String:(const char *)
                                        sqlite3_column_text(statement, 2)];
                _employeecode.text = employeecode;
                NSString *tagline = [[NSString alloc]
                                          initWithUTF8String:(const char *)
                                          sqlite3_column_text(statement, 4)];
                _tagline.text = tagline;
                NSString *department = [[NSString alloc]
                                          initWithUTF8String:(const char *)
                                          sqlite3_column_text(statement, 3)];
                _department.text = department;

                _status.text = @"Match found";
            } else {
                _status.text = @"Match not found";
                _name.text=@"";
                _tagline.text=@"";
                _department.text=@"";
                _employeecode.text = @"";
                _designation.text = @"";
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(_contactDB);
    }
}
- (void)didReceiveMemoryWarning
    {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    }

@end
