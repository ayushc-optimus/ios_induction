//
//  AppDelegate.h
//  database
//
//  Created by ayush on 2/17/15.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

