//
//  TableVC.h
//  database
//
//  Created by ayush on 2/18/15.
//
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface TableVC : UITableViewController<UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *contactDB;
@end