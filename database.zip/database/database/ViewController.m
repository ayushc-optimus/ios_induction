//
//  ViewController.m
//  database
//
//  Created by ayush on 2/17/15.
//
//

#import "ViewController.h"
#import "firstview.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}
- (IBAction)add:(id)sender {

}
- (IBAction)search:(id)sender {

}
-(IBAction)browse:(id)sender{
    
}
@end
