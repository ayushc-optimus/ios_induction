//
//  CallOut.m
//  MapApp
//
//  Created by Optimus Information on 08/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import "CallOut.h"

@implementation CallOut

@end
