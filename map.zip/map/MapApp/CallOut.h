//
//  CallOut.h
//  MapApp
//
//  Created by Optimus Information on 08/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  This class handles the custom CallOut view.
 */
@interface CallOut : UIView

/**
 *  Referencing outlet for the button in callout view.
 */
@property (strong, nonatomic) IBOutlet UIButton *btn;

@end
