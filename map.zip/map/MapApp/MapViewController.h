//
//  ViewController.h
//  MapApp
//
//  Created by Optimus Information on 07/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

/**
 *  This class handles the user location and the type of map displayed.
 */
@interface MapViewController : UIViewController <MKMapViewDelegate,CLLocationManagerDelegate>

/**
 *  References for the Map View and the Segmented Control.
 */
@property (strong, nonatomic) IBOutlet MKMapView *myMap;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segment;

/**
 *  Action defined on changing the value of segmented control.
 *
 *  @param sender Gets the id of the sender which calls this function.
 */
- (IBAction)changeMapType:(id)sender;

@end
