//
//  MyLocationControllerViewController.h
//  MapApp
//
//  Created by Optimus Information on 07/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

/**
 *  This class handles display of custom annotations.
 */
@interface MyLocationControllerViewController : UIViewController <MKMapViewDelegate>

/**
 *  Reference to the Map View.
 */
@property (strong, nonatomic) IBOutlet MKMapView *myMap;

@end
