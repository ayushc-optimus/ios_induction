//
//  ViewController.m
//  MapApp
//
//  Created by Optimus Information on 07/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import "MapViewController.h"
#import <CoreLocation/CoreLocation.h>
#define SYSTEM_VERSION_LESS_THAN(v)([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
@interface MapViewController ()
{
CLLocationManager *locationManager;
}
@end

/**
 *  Implementation of the Map View Controller class.
 */
@implementation MapViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.myMap.showsUserLocation = YES;
    [CLLocationManager locationServicesEnabled];
    locationManager = [[CLLocationManager alloc] init];
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.delegate = self;
    [locationManager startUpdatingLocation];
    if (!SYSTEM_VERSION_LESS_THAN(@"8.0"))
    {
        [locationManager requestWhenInUseAuthorization];
        
    }
    

	// Do any additional setup after loading the view, typically from a nib.
    
    // Sets the delegate of the map to self since it conforms to the Map Delegate protocol.
    self.myMap.delegate = self;
}

/**
 *  Action defined on changing the value of segmented control.
 *
 *  @param sender Gets the id of the sender which calls this function.
 */
- (IBAction)changeMapType:(id)sender;
{
    // Sets the map type based on the selection in the Segmented Control.
    switch (self.segment.selectedSegmentIndex)
    {
        case 0:
            self.myMap.MapType = MKMapTypeStandard;
            break;
        case 1:
            self.myMap.MapType = MKMapTypeSatellite;
            break;
        case 2:
            self.myMap.MapType = MKMapTypeHybrid;
            break;
    }
}

/**
 *  This function gets called when the location of the user is updated.
 *
 *  @param mapView      The Map View in which user's location has been updated.
 *  @param userLocation Gets the user location.
 */
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 800, 800);
    
    // Sets the center coordinate of the map to user's location.
//    [self.myMap setCenterCoordinate:userLocation.coordinate animated:YES];
    
    // Sets the surrounding region of the map to a region with certain distance in each direction.
    [self.myMap setRegion:[self.myMap regionThatFits:region] animated:YES];
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end