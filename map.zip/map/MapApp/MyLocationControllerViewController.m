//
//  MyLocationControllerViewController.m
//  MapApp
//
//  Created by Optimus Information on 07/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import "MyLocationControllerViewController.h"
#import "DetailsViewController.h"
#import "MyAnnotation.h"
#import "CallOut.h"

@interface MyLocationControllerViewController ()
{
    CallOut *calloutView;
    /**
     *  Strings to store placemark information after reverse geocoding.
     */
    NSString *city, *country, *state;
}
@end

/**
 *  Implementation of My Location View Controller class.
 */
@implementation MyLocationControllerViewController

- (void)viewWillAppear:(BOOL)animated
{
    // Sets the delegate of the map to self since it conforms to the Map Delegate protocol.
    self.myMap.delegate = self;
    
    // Defines a custom location.
    CLLocationCoordinate2D myCoord = CLLocationCoordinate2DMake(28.625786, 77.373190);
    //CLLocationCoordinate2D myCoord = CLLocationCoordinate2DMake(40.1430241,-74.7311156);
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(myCoord, 800, 800);
    
    // Sets the surrounding region of the map to a region with certain distance in each direction.
    [self.myMap setRegion:[self.myMap regionThatFits:region] animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    // Sets the delegate of the map to self since it conforms to the Map Delegate protocol.
    self.myMap.delegate = self;
    
    // Defines a custom location.
    CLLocationCoordinate2D myCoord = CLLocationCoordinate2DMake(28.625786, 77.373190);
    //CLLocationCoordinate2D myCoord = CLLocationCoordinate2DMake(40.1430241,-74.7311156);
    CLGeocoder *reverseGeocoder = [[CLGeocoder alloc] init];
    CLLocation *myLoc = [[CLLocation alloc] initWithLatitude:myCoord.latitude longitude:myCoord.longitude];
    MyAnnotation *annotation = [[MyAnnotation alloc] initWithCoordinate:myCoord title:@"Optimus"];
    
    // Adds the above defined annotation to the Map View.
    [self.myMap addAnnotation:annotation];
    
    // Get reverse geocoding of the given location and access the nearest placemark information.
    [reverseGeocoder reverseGeocodeLocation:myLoc completionHandler:^(NSArray *placemarks, NSError *error)
     {
         NSLog(@"reverseGeocodeLocation:completionHandler: Completion Handler called!");
         if (error){
             NSLog(@"Geocode failed with error: %@", error);
             return;
         }
         NSLog(@"Received placemarks");
         CLPlacemark *myPlacemark = [placemarks objectAtIndex:0];
         NSString *countryCode = myPlacemark.ISOcountryCode;
         NSString *countryName = myPlacemark.country;
         NSString *stateName = myPlacemark.administrativeArea;
         NSString *cityName = myPlacemark.locality;
         NSLog(@"Location: %@\n%@, %@, %@", countryName, cityName, stateName, countryCode);
         [self savePlacemarksForAnnotation:myCoord withCountry:countryName withState:stateName withCity:cityName];
     }];
}

/**
 *  Saves the placemarks permanently *
 *  @param myCoord     Gives the coordinate for which we are receiving palcemarks.
 
 */
- (void) savePlacemarksForAnnotation:(CLLocationCoordinate2D)myCoord withCountry:(NSString *)countryName withState:(NSString *)stateName withCity:(NSString *)cityName
{
    country = countryName;
    city = cityName;
    state = stateName;
}

/**
 *  Selector function of touch up inside event for the button on callout.
 */
-(void)buttonTapped {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"View Details" message:@"Click Cancel to Go Back or OK to View Details of this Location" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [alertView show];
}

/**
 *  Performed when a button in alert view is clicked.
 *
 *  @param alertView   Gets the alert view on which the button is clicked.
 *  @param buttonIndex Gets the index of the button which is pressed in the alert view.
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // Checks if the OK button is pressed. If it is pressed, a segue by the name showDetails is performed.
    if (buttonIndex == 1){
        [self performSegueWithIdentifier:@"showDetails" sender:self];
    }
}

/**
 *  Prepares the view for segue to happen. This is called just before the segue.
 *
 *  @param segue  Recieves the segue which is about to happen.
 *  @param sender Gets the id of the sender which calls this function..
 */
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Checks if the identifier of the segue corresponds to the segue we want to customize and does the customization, sending information in this case.
    if ([segue.identifier isEqualToString:@"showDetails"]) {
        DetailsViewController *destViewController = segue.destinationViewController;
        destViewController.city = city;
        destViewController.state = state;
        destViewController.country = country;
    }
}

/**
 *  This function is called each time an annotation is added to the map view.
 
 *  @return Returns the view to be used for annotation.
 */
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id)annotation {
    // Checks if the annotation is of class MKUserLocation, i.e., if it is the user's location. If it is true, it returns nil, i.e., makes no changes to the annotation.
    if([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    static NSString *identifier = @"myAnnotation";
    
    // A new annotation view of type my annotation is initialized with a reusable component of same type and identifier.
    MyAnnotation *annotationView = (MyAnnotation *)[self.myMap dequeueReusableAnnotationViewWithIdentifier:identifier];
    // If no existing annotation component is reusable, a new one is created.
    if (!annotationView)
    {
        annotationView = [[MyAnnotation alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        annotationView.image = [UIImage imageNamed:@"pin.png"];
    }
    
    // If a reusable component is found, it is set to current annotation.
    else {
        annotationView.annotation = annotation;
    }
    
    // A view to be used for annotation is returned.
    return annotationView;
}

/**
 *  This function is called when an annotation is selected.
 *
 *  @param mapView Gets the map view in which the annotation is selected.
 *  @param view    Gets the annotation view which is selected.
 */
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view {
    // Checks if the annotation in the received view is of type MKUserLocation. If not, it initializes an instance of the nib named CallOut to be used as callout view for this annotaion.
    if(![view.annotation isKindOfClass:[MKUserLocation class]]) {
        calloutView = (CallOut *)[[[NSBundle mainBundle] loadNibNamed:@"CallOut" owner:self options:Nil] objectAtIndex:0];
        
        // Sets the origin of callout view appropriately.
        CGRect calloutViewFrame = calloutView.frame;
        calloutViewFrame.origin = CGPointMake(-calloutViewFrame.size.width/2 + 15, -calloutViewFrame.size.height);
        calloutView.frame = calloutViewFrame;
        
        // Adds selector to the button in the callout view for the event touch up inside.
        [calloutView.btn addTarget:self action:@selector(buttonTapped) forControlEvents:UIControlEventTouchUpInside];
        
        // Adds the callout view as a subview to the annotation.
        [view addSubview:calloutView];
    }
}

/**
 *  This function is called when an annotation is deselected.
 *
 *  @param mapView Gets the map view in which the annotation is selected.
 *  @param view    Gets the annotation view which is selected.
 */
-(void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view {
    // Removes the callout view from its superview.
    [calloutView removeFromSuperview];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end