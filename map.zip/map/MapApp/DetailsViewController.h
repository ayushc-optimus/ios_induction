//
//  DetailsViewController.h
//  MapApp
//
//  Created by Optimus Information on 08/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  This class handles the details view controller.
 */
@interface DetailsViewController : UIViewController

/**
 *  Referencin outlets for city, state and country fields of the details view controller.
 */
@property (strong, nonatomic) IBOutlet UILabel *cityLabel;
@property (strong, nonatomic) IBOutlet UILabel *stateLabel;
@property (strong, nonatomic) IBOutlet UILabel *countryLabel;
@property (strong, nonatomic) NSString *city, *state, *country;

@end
