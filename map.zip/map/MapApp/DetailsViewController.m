//
//  DetailsViewController.m
//  MapApp
//
//  Created by Optimus Information on 08/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import "DetailsViewController.h"

@interface DetailsViewController ()

@end

/**
 *  Implementation of the class Details View Controller.
 */
@implementation DetailsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    // Assigns each label from segue to the respective outlets.
    self.cityLabel.text = self.city;
    self.stateLabel.text = self.state;
    self.countryLabel.text = self.country;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
