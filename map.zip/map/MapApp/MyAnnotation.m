//
//  MyAnnotation.m
//  MapApp
//
//  Created by Optimus Information on 08/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import "MyAnnotation.h"

/**
 *  Implementation of MyAnnotation class.
 */
@implementation MyAnnotation

/**
 *  Initializes an annotation with the given coordinate and title.
 *
 *  @param coordinate Gives the coordinate at which this annotation will be added.
 *  @param title      Gives a title to the annotaion.
 *
 *  @return Returns the id of the newly initialized annotation.
 */
-(id) initWithCoordinate:(CLLocationCoordinate2D)coordinate title:(NSString *)title {
    if ((self = [super init])) {
        self.coordinate = coordinate;
        self.title = title;
    }
    return self;
}

/**
 *  Performs test on subviews to know if they respond to the touch for passing the event to subviews.
 *
 *  @param point Gives the point at which the event takes place.
 *  @param event Gives the event which has taken place at the given point.
 *
 *  @return Returns the view which responds to the event.
 */
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (!self.clipsToBounds && !self.hidden && self.alpha > 0) {
        for (UIView *subview in self.subviews.reverseObjectEnumerator) {
            CGPoint subPoint = [subview convertPoint:point fromView:self];
            UIView *result = [subview hitTest:subPoint withEvent:event];
            if (result != nil) {
                return result;
                break;
            }
        }
    }
    
    // Passes the event onward in case no subviews trigger the event.
    return [super hitTest:point withEvent:event];
}

@end