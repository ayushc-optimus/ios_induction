//
//  AppDelegate.h
//  MapApp
//
//  Created by Optimus Information on 07/07/14.
//  Copyright (c) 2014 Optimus Information. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
