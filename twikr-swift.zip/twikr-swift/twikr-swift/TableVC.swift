//
//  TableVC.swift
//  twikr-swift
//
//  Created by ayush on 3/9/15.
//  Copyright (c) 2015 optimus. All rights reserved.
//

import UIKit

class TableVC: UITableViewCell
{
    @IBOutlet weak var textv: UITextView!
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
