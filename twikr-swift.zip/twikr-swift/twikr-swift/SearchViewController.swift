//
//  SearchViewController.swift
//  twikr-swift
//
//  Created by ayush on 3/9/15.
//  Copyright (c) 2015 optimus. All rights reserved.
//

import UIKit
import Social
import Accounts

class SearchViewController: UITableViewController {

    var dataSource = [AnyObject]()
    var query: String!
    var connection : NSURLConnection?
    var buffer:NSMutableData?
    var accountStore:ACAccountStore?
     @IBOutlet weak var tweetTableView: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        self.title = self.query
        self.loadQuery()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // Return the number of rows in the section.
       return dataSource.count
    }
   
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var identifier : NSString = "Result"
        let cell = tweetTableView.dequeueReusableCellWithIdentifier(identifier) as TableVC
        let row = indexPath.row
        let tweet : NSDictionary = (self.dataSource)[indexPath.row] as NSDictionary
        cell.textv.text = tweet.objectForKey("text") as NSString
        return cell
     }
        
    func loadQuery()
    {   let encodedQuery = query.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)
       
        let account = ACAccountStore()
        let accountType = account.accountTypeWithAccountTypeIdentifier(
            ACAccountTypeIdentifierTwitter)
        
        account.requestAccessToAccountsWithType(accountType, options: nil,
            completion: {(success: Bool, error: NSError!) -> Void in
                
                if success {
                    // Get account and communicate with Twitter API
                    let arrayOfAccounts =
                    account.accountsWithAccountType(accountType)
                    
                    if arrayOfAccounts.count > 0 {
                        let twitterAccount = arrayOfAccounts.last as ACAccount
                    let requestURL = NSURL(string:
                        "https://api.twitter.com/1.1/statuses/user_timeline.json")
                    let parameters  = ["screen_name" : "@optimus","q":"encodedQuery","count":"20"]
                    let postRequest = SLRequest(forServiceType:
                        SLServiceTypeTwitter,
                        requestMethod: SLRequestMethod.GET,
                        URL: requestURL,
                        parameters:parameters)
                    
                    postRequest.account = twitterAccount
                    
                    postRequest.performRequestWithHandler(
                        {(responseData: NSData!,
                            urlResponse: NSHTTPURLResponse!,
                            error: NSError!) -> Void in
                            var err: NSError?
                            self.dataSource = NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.MutableLeaves, error: &err) as [AnyObject]
                            
                            if self.dataSource.count != 0
                            {
                                dispatch_async(dispatch_get_main_queue()) {
                                    self.tweetTableView.reloadData()
                                    }
                            }
                    })
                        
                    }
                } else
                {
                    println("Failed to access account")
                }
        })
    }
}