//
//  FlickrPhotoCell.swift
//  twikr-swift
//
//  Created by ayush on 3/4/15.
//  Copyright (c) 2015 optimus. All rights reserved.
//

import UIKit

class FlickrPhotoCell: UICollectionViewCell
{   
    @IBOutlet var imagev: UIImageView!
}
