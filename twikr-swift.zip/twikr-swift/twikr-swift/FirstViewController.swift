//
//  FirstViewController.swift
//  twikr-swift
//
//  Created by ayush on 3/4/15.
//  Copyright (c) 2015 optimus. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController,UITextFieldDelegate
{
    @IBOutlet weak var textf: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.textf.delegate = self;

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool
    {   //delegate method
        textField.resignFirstResponder()
        return true
    }
    
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!){
    if (segue.identifier=="SegueSearchView")
    {
        let sender=textf
       var svc = segue.destinationViewController as SearchViewController;
        svc.query = textf.text
    }
}
    



}

