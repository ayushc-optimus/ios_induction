//
//  ViewController.h
//  camera
//
//  Created by ayush on 2/5/15.
//  Copyright (c) 2015 ayush. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>


@interface ViewController : UIViewController <UIImagePickerControllerDelegate,
    UINavigationControllerDelegate>

@property BOOL newMedia;
@property (weak, nonatomic) IBOutlet UIButton *select;
@property (weak, nonatomic) IBOutlet UIButton *capture;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

- (IBAction)Capture:(id)sender;
- (IBAction)Select:(id)sender;

@end

